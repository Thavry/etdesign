<template>
    <footer class="footer">
        This is the footer.
    </footer>
</template>